(function(){/**
 * Configure environment variables
 */

})();
