(function(){Meteor.startup(function(){
    // fixtures
    // APP.namespace('FIXTURES').init();
});

})();
