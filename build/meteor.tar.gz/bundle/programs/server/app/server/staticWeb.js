(function(){// static web

})();
