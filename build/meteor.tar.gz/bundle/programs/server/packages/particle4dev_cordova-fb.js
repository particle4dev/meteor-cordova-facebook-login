(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var Accounts = Package['accounts-base'].Accounts;
var Facebook = Package.facebook.Facebook;
var ServiceConfiguration = Package['service-configuration'].ServiceConfiguration;
var HTTP = Package.http.HTTP;
var _ = Package.underscore._;

(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 //
// packages/particle4dev:cordova-fb/facebook_server.js                                             //
//                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                   //
Accounts.registerLoginHandler(function(loginRequest) {                                             // 1
  if(!loginRequest.cordova) {                                                                      // 2
    return undefined;                                                                              // 3
  }                                                                                                // 4
                                                                                                   // 5
  loginRequest = loginRequest.authResponse;                                                        // 6
  var identity = getIdentity(loginRequest.accessToken);                                            // 7
  var profilePicture = getProfilePicture(loginRequest.accessToken);                                // 8
                                                                                                   // 9
  var serviceData = {                                                                              // 10
    accessToken: loginRequest.accessToken,                                                         // 11
    expiresAt: (+new Date) + (1000 * loginRequest.expiresIn)                                       // 12
  };                                                                                               // 13
                                                                                                   // 14
  var whitelisted = ['id', 'email', 'name', 'first_name',                                          // 15
      'last_name', 'link', 'username', 'gender', 'locale', 'age_range'];                           // 16
                                                                                                   // 17
  var fields = _.pick(identity, whitelisted);                                                      // 18
  _.extend(serviceData, fields);                                                                   // 19
                                                                                                   // 20
  var options = {profile: {}};                                                                     // 21
  var profileFields = _.pick(identity, Meteor.settings.public.facebook.profileFields);             // 22
  _.extend(options.profile, profileFields);                                                        // 23
                                                                                                   // 24
  options.profile.avatar = profilePicture;                                                         // 25
                                                                                                   // 26
  return Accounts.updateOrCreateUserFromExternalService("facebook", serviceData, options);         // 27
                                                                                                   // 28
});                                                                                                // 29
                                                                                                   // 30
var getIdentity = function (accessToken) {                                                         // 31
  try {                                                                                            // 32
    return HTTP.get("https://graph.facebook.com/me", {                                             // 33
      params: {access_token: accessToken}}).data;                                                  // 34
  } catch (err) {                                                                                  // 35
    throw _.extend(new Error("Failed to fetch identity from Facebook. " + err.message),            // 36
                   {response: err.response});                                                      // 37
  }                                                                                                // 38
};                                                                                                 // 39
                                                                                                   // 40
var getProfilePicture = function (accessToken) {                                                   // 41
  try {                                                                                            // 42
    return HTTP.get("https://graph.facebook.com/v2.0/me/picture/?redirect=false", {                // 43
      params: {access_token: accessToken}}).data.data.url;                                         // 44
  } catch (err) {                                                                                  // 45
    throw _.extend(new Error("Failed to fetch identity from Facebook. " + err.message),            // 46
                   {response: err.response});                                                      // 47
  }                                                                                                // 48
};                                                                                                 // 49
                                                                                                   // 50
                                                                                                   // 51
  Accounts.oauth.registerService('facebook');                                                      // 52
  if (Meteor.settings &&                                                                           // 53
      Meteor.settings["cordova"] &&                                                                // 54
      Meteor.settings["cordova"]["com.phonegap.plugins.facebookconnect"] &&                        // 55
      Meteor.settings["cordova"]["com.phonegap.plugins.facebookconnect"].APP_ID &&                 // 56
      Meteor.settings["cordova"]["com.phonegap.plugins.facebookconnect"].secret) {                 // 57
                                                                                                   // 58
    ServiceConfiguration.configurations.remove({                                                   // 59
      service: "facebook"                                                                          // 60
    });                                                                                            // 61
                                                                                                   // 62
    ServiceConfiguration.configurations.insert({                                                   // 63
      service: "facebook",                                                                         // 64
      appId: Meteor.settings["cordova"]["com.phonegap.plugins.facebookconnect"].APP_ID,            // 65
      secret: Meteor.settings["cordova"]["com.phonegap.plugins.facebookconnect"].secret            // 66
    });                                                                                            // 67
                                                                                                   // 68
    Accounts.addAutopublishFields({                                                                // 69
      // publish all fields including access token, which can legitimately                         // 70
      // be used from the client (if transmitted over ssl or on                                    // 71
      // localhost). https://developers.facebook.com/docs/concepts/login/access-tokens-and-types/, // 72
      // "Sharing of Access Tokens"                                                                // 73
      forLoggedInUser: ['services.facebook'],                                                      // 74
      forOtherUsers: [                                                                             // 75
        // https://www.facebook.com/help/167709519956542                                           // 76
        'services.facebook.id', 'services.facebook.username', 'services.facebook.gender'           // 77
      ]                                                                                            // 78
    });                                                                                            // 79
                                                                                                   // 80
  } else {                                                                                         // 81
    console.log("Meteor settings for accounts-facebook-cordova not configured correctly.");        // 82
  }                                                                                                // 83
                                                                                                   // 84
/////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['particle4dev:cordova-fb'] = {};

})();

//# sourceMappingURL=particle4dev_cordova-fb.js.map
